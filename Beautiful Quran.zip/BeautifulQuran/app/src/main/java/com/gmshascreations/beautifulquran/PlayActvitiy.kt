package com.gmshascreations.beautifulquran

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class PlayActvitiy : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_play_actvitiy)
    }
}